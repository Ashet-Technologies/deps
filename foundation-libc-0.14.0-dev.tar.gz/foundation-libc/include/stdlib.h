#ifndef _FOUNDATION_LIBC_STDLIB_H_
#define _FOUNDATION_LIBC_STDLIB_H_

int atoi(char const * str);

#endif
